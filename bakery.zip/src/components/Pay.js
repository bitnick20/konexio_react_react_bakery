import React from 'react';


class Pay extends React.Component {
    render () {
        console.log("cmp/#Pay this props :", this.props);
        return (
            <div>
                Pay
            </div>
        );
    }
}

export default Pay;